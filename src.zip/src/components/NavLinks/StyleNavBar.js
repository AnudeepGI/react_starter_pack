import React from 'react'
import { NavLink } from "react-router-dom";
import { useDispatch, useSelector } from 'react-redux';


export default function StyleNavBar() {
  const counter = useSelector((state)=>state.counter)
  const dispatch = useDispatch();
  const increament = () => dispatch({type:'INC'});
  const decreament = () => dispatch({type:'DEC'});
  const addTen = () => dispatch({type:'ADDTEN',payload:10});
  return (
    <>
      <h3>{counter}</h3>
      <button onClick={increament}>Increase</button>
      <button onClick={decreament}>Decrease</button> <br/>
      <button onClick={addTen}>Add by 10</button> <br/>
      <NavLink to="/"
        className={({ isActive }) => isActive ? "activeClassName" : "inactiveclassnaem"}
      >Home</NavLink><br />
      <NavLink to="/about"
        className={({ isActive }) => isActive ? "activeClassName" : "inactiveclassnaem"}
      >About</NavLink><br />
      <NavLink to="/product"
        className={({ isActive }) => isActive ? "activeClassName" : "inactiveclassnaem"}
      >product</NavLink>
    </>
  )
}
