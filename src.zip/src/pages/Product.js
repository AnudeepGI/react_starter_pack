import React from 'react'
import NavLinks from '../components/NavLinks'

export default function Product() {
    return (
        <><br />Product</>
    )
}
