import React from 'react'
import { Outlet } from 'react-router-dom'
import NavLinks from '../components/NavLinks'
export default function Home() {
    return (
        <>
            <br />Home 
        </>
    )
}
