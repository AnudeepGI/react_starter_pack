import React from 'react'

export default function SecView() {
    return (
        <>
            <br />SecView
        </>
    )
}
