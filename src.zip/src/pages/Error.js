import React from 'react'

export default function Error() {
    return (
        <><br />Page not Found</>
    )
}
