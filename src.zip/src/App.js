import { BrowserRouter, Routes, Route, Outlet, Navigate } from 'react-router-dom';
import './App.css';
import About from './pages/About';
import Error from './pages/Error';
import Home from './pages/Home';
import Product from './pages/Product';
import NavLinks from './components/NavLinks'
import SharedLayout from './Layout';
import SecView from './pages/SecView';
import React, { useState } from 'react'

const ProtectedRoutes = ({children,isLogin}) => {
  console.log(isLogin)
  if(!isLogin) {
    return <Navigate to="/" />
  } 
  return children;
}

function App() {
  const [isLogin, setisLogin] = useState(false)

  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<SharedLayout/>}>
          <Route index element={<Home/>}/>
          <Route path='about' element={<About/>}/>
          <Route path='product' element={<Product/>}/>
          <Route path='*' element={<Error/>}/>
        </Route>
        <Route path='dashbord' element={
          <ProtectedRoutes isLogin={isLogin}>
            <SharedLayout />
          </ProtectedRoutes>
        }>
          <Route index element={<SecView/>}/>
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
